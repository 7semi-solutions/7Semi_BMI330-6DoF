#include "7Semi_BMI330.h"

/* =========================
 * Constructors
 * ========================= */

BMI330_7Semi::BMI330_7Semi()
{}
/* =========================
 * Begin / Reset
 * ========================= */

bool BMI330_7Semi::begin()
{
  // If bus not selected, default to I2C
  if (bus == Bus::NONE)
  {
    if (!beginI2C()) return false;
  }

  uint16_t chip = 0;
  if (!readChipID(chip)) return false;
  if (chip != BMI330_CHIP_ID_VALUE) return false;
  if (!softReset()) return false;
  delay(10);

  // Default configuration
  if (!setAccelConfig(ODR_100HZ, ACC_RANGE_2G, BW_ODR_DIV2, AVG_64, MODE_HIGH_PERFORMANCE)) return false;
  if (!setGyroConfig(ODR_100HZ, GYR_RANGE_2000DPS, BW_ODR_DIV2, AVG_64, MODE_HIGH_PERFORMANCE)) return false;

  return true;
}

bool BMI330_7Semi::beginI2C(uint8_t i2cAddress,
                            TwoWire &i2CPort,
                            uint32_t ClockSpeed,
                            uint8_t SDA,
                            uint8_t SCL)
{
  bus = Bus::I2C;

  address = i2cAddress;
  i2c = &i2CPort;
  i2c_clock_speed = ClockSpeed;

#if defined(ARDUINO_ARCH_ESP32) || defined(ARDUINO_ARCH_ESP8266)
  i2c->setPins(SDA, SCL);
  i2c->begin();
#else
  i2c->begin();
#endif

  i2c->setClock(i2c_clock_speed);

  i2c->beginTransmission(address);
  if (i2c->endTransmission(true) != 0)
    return false;

  // IMPORTANT: do NOT call beginI2C again (avoid recursion)
  return begin();
}

bool BMI330_7Semi::beginSPI(uint8_t spiCS,
                            SPIClass &spiPort,
                            uint32_t ClockSpeed,
                            uint8_t sck,
                            uint8_t miso,
                            uint8_t mosi)
{
  bus = Bus::SPI;

  cs = spiCS;
  spi = &spiPort;
  spi_clock_speed = ClockSpeed;

  pinMode(cs, OUTPUT);
  digitalWrite(cs, HIGH);

#if defined(ARDUINO_ARCH_ESP32)
  spi->begin(sck, miso, mosi);
#else
  spi->begin();
#endif

  return begin();
}


bool BMI330_7Semi::softReset()
{
  return writeReg(BMI330_REG_CMD, BMI330_CMD_SOFT_RESET);
}

bool BMI330_7Semi::writeReg(uint8_t reg, uint16_t value)
{
    uint8_t data[2] = { 0,0};
    data[0] = (uint8_t)(value & 0xFF);
    data[1] = (uint8_t)((value >> 8) & 0xFF);
    
    if (bus == Bus::I2C)
    {
        return i2cWrite(reg, data, 2);
    }

    return spiWrite(reg, data, 2);
}

bool BMI330_7Semi::readReg(uint8_t reg, uint16_t &value)
{
    uint8_t buf[4] = {0, 0};
    if (!readBurst(reg, buf, 2)) return false;
    value = (uint16_t)buf[1] << 8 | buf[0]; // MSB << 8 | LSB
    return true;
}

bool BMI330_7Semi::readBurst(uint8_t startReg, uint8_t *buffer, size_t length)
{
    if (bus == Bus::I2C)
    {
        return i2cRead(startReg, buffer, length);
    }

    return spiRead(startReg, buffer, length);
}

/* =========================
 * I2C helpers
 * ========================= */
bool BMI330_7Semi::i2cRead(uint8_t reg, uint8_t *buf, size_t len)
{
    i2c->beginTransmission(address);
    i2c->write(reg);
    if (i2c->endTransmission(false) != 0) ;//return false;
  

    const size_t dummyBytes = 2;
    const size_t total = len + dummyBytes;

    if (i2c->requestFrom((int)address, (int)total) != (int)total) return false;
    for (size_t i = 0; i < dummyBytes; i++) (void)i2c->read(); // discard dummy bytes
    for (size_t i = 0; i < len; i++) buf[i] = (uint8_t)i2c->read();

    return true;
}

bool BMI330_7Semi::i2cWrite(uint8_t reg, const uint8_t *buf, size_t len)
{
    i2c->beginTransmission(address);
    i2c->write(reg);
    i2c->write(buf, len); // use len, not hard-coded 2
    return (i2c->endTransmission() == 0);
}

/* =========================
 * SPI helpers
 * ========================= */
bool BMI330_7Semi::spiRead(uint8_t reg, uint8_t *buf, size_t len)
{
    spi->beginTransaction(SPISettings(spi_clock_speed, MSBFIRST, SPI_MODE0));
    digitalWrite(cs, LOW);

    spi->transfer((uint8_t)(0x80 | (reg & 0x7F))); // set MSB=1 for read
    (void)spi->transfer(0x00);                     // dummy byte

    for (size_t i = 0; i < len; i++)
        buf[i] = spi->transfer(0x00);

    digitalWrite(cs, HIGH);
    spi->endTransaction();

    return true;
}

bool BMI330_7Semi::spiWrite(uint8_t reg, const uint8_t *buf, size_t len)
{
    spi->beginTransaction(SPISettings(spi_clock_speed, MSBFIRST, SPI_MODE0));
    digitalWrite(cs, LOW);

    spi->transfer((uint8_t)(reg & 0x7F)); // MSB=0 for write
    for (size_t i = 0; i < len; i++)
        spi->transfer(buf[i]);

    digitalWrite(cs, HIGH);
    spi->endTransaction();

    return true;
}

/* =========================
 * Basic status
 * ========================= */

bool BMI330_7Semi::readChipID(uint16_t &chipId)
{
  if (!readReg(BMI330_REG_CHIP_ID, chipId)) return false;
  return true;
}

bool BMI330_7Semi::readStatus(uint16_t &statusWord)
{
  return readReg(BMI330_REG_STATUS, statusWord);
}

bool BMI330_7Semi::readError(uint16_t &error)
{
  return readReg(BMI330_REG_ERR_REG, error);
}

/* =========================
 * Configuration
 * ========================= */
 uint16_t BMI330_SET_BITS(uint16_t v, uint8_t pos, uint8_t width, uint16_t field) {
  const uint16_t mask = (uint16_t)(BMI330_MASK(width) << pos);
  return (uint16_t)((v & ~mask) | ((field << pos) & mask));
}
bool BMI330_7Semi::_updateRegisterField(uint8_t reg, uint8_t pos, uint8_t width, uint16_t fieldValue)
{
  uint16_t v = 0;
  if (!readReg(reg, v)) return false;
  v = BMI330_SET_BITS(v, pos, width, fieldValue);
  return writeReg(reg, v);
}
// Read a single bit from a 16-bit register value
// Read a single bit from a 16-bit register
bool BMI330_7Semi::readBit(uint8_t reg, uint8_t bitPos, bool &bitValue) {
    uint16_t v = 0;
    if (!readReg(reg, v)) return false;  // Failed to read register

    bitValue = ((v >> bitPos) & 0x01) != 0;  // Extract the bit
    return true;                             // Success
}

// Write a single bit into a 16-bit register
// Write a single bit in a 16-bit register
bool BMI330_7Semi::writeBit(uint8_t reg, uint8_t bitPos, bool bitVal)
{
    uint16_t v = 0;

    // Read the current 16-bit register value
    if (!readReg(reg, v)) return false;

    if (bitVal)
        v |= (1u << bitPos);   // Set the bit
    else
        v &= ~(1u << bitPos);  // Clear the bit

    // Write the updated 16-bit value back
    return writeReg(reg, v);
}


bool BMI330_7Semi::setAccelConfig(ODR odr, AccRange range, BW bw, AVG avg, Mode mode)
{
    accel_range = range;

    uint16_t v = 0;
    if (!readReg(BMI330_REG_ACC_CONF, v)) return false;

    // Clear and set ODR bits (4 bits)
    v &= ~(0x0F << 0);          // ODR is 4 bits at position 0
    v |= ((uint16_t)odr << 0);

    // Clear and set range bits (3 bits)
    v &= ~(0x07 << 4);          // Range is 3 bits at position 4
    v |= ((uint16_t)range << 4);

    // Clear and set bandwidth bits (1 bit)
    v &= ~(0x01 << 7);          // BW is 1 bit at position 7
    v |= ((uint16_t)bw << 7);

    // Clear and set averaging bits (3 bits)
    v &= ~(0x07 << 8);          // AVG is 3 bits at position 8
    v |= ((uint16_t)avg << 8);

    // Clear and set mode bits (3 bits)
    v &= ~(0x07 << 12);         // Mode is 3 bits at position 12
    v |= ((uint16_t)mode << 12);

    return writeReg(BMI330_REG_ACC_CONF, v);
}


bool BMI330_7Semi::setGyroConfig(ODR odr, GyrRange range, BW bw, AVG avg, Mode mode)
{
  gyro_range = range;

  uint16_t v = 0;
  if (!readReg(BMI330_REG_GYR_CONF, v)) return false;

   // Clear and set ODR bits (bits 0-3)
    v &= ~(0x0F << 0);
    v |= ((uint16_t)odr << 0);

    // Clear and set range bits (bits 4-6)
    v &= ~(0x07 << 4);
    v |= ((uint16_t)range << 4);

    // Clear and set bandwidth bits (bit 7)
    v &= ~(0x01 << 7);
    v |= ((uint16_t)bw << 7);

    // Clear and set averaging bits (bits 8-10)
    v &= ~(0x07 << 8);
    v |= ((uint16_t)avg << 8);

    // Clear and set mode bits (bits 12-14)
    v &= ~(0x07 << 12);
    v |= ((uint16_t)mode << 12);
  return writeReg(BMI330_REG_GYR_CONF, v);
}

/* =========================
 * Sensor output reads
 * ========================= */

bool BMI330_7Semi::readAccelRaw(int16_t &ax, int16_t &ay, int16_t &az)
{
  uint8_t buf[6];
  if (!readBurst(BMI330_REG_ACC_DATA_X, buf, sizeof(buf))) return false;
  ax = bytesToUint16(buf[0], buf[1]);
  ay = bytesToUint16(buf[2], buf[3]);
  az = bytesToUint16(buf[4], buf[5]);
  return true;
}

bool BMI330_7Semi::readGyroRaw(int16_t &gx, int16_t &gy, int16_t &gz)
{
  uint8_t buf[6];
  if (!readBurst(BMI330_REG_GYR_DATA_X, buf, sizeof(buf))) return false;
  gx = bytesToUint16(buf[0], buf[1]);
  gy = bytesToUint16(buf[2], buf[3]);
  gz = bytesToUint16(buf[4], buf[5]);
  return true;
}

bool BMI330_7Semi::readTemperatureRaw(int16_t &t)
{
  uint8_t buf[2];
  if (!readBurst(BMI330_REG_TEMP_DATA, buf, sizeof(buf))) return false;
  t = bytesToUint16(buf[0], buf[1]);
  return true;
}

bool BMI330_7Semi::readSensorTime(uint32_t &time24)
{
  /**
   * Sensor time is 24 bits across 3 words (sensortime_0..2).
   * We read 6 bytes (3 words LSB/MSB), then build 24-bit value from the documented LSB ordering.
   */
  uint8_t buf[6];
  if (!readBurst(BMI330_REG_SENSORTIME_0, buf, sizeof(buf))) return false;

  const uint16_t v0 = (uint16_t)buf[1] << 8 | buf[0];
  const uint16_t v1 = (uint16_t)buf[3] << 8 | buf[2];
  const uint16_t v2 = (uint16_t)buf[5] << 8 | buf[4];

  /* Keep 24 bits (LSBs). Exact bit-usage depends on datasheet; common BMI3-style is 24-bit counter */
  time24 = ((uint32_t)(v2 & 0x00FF) << 16) | ((uint32_t)(v1 & 0x00FF) << 8) | (uint32_t)(v0 & 0x00FF);
  return true;
}

float BMI330_7Semi::accelLsbPerMg() const
{
  switch (accel_range)
  {
    case ACC_RANGE_2G:  return 16.38f;
    case ACC_RANGE_4G:  return 8.19f;
    case ACC_RANGE_8G:  return 4.10f;
    case ACC_RANGE_16G: return 2.05f;
    default:            return 16.38f;
  }
}

float BMI330_7Semi::gyroLsbPerDps() const
{
  switch (gyro_range)
  {
    case GYR_RANGE_125DPS:  return 262.144f;
    case GYR_RANGE_250DPS:  return 131.072f;
    case GYR_RANGE_500DPS:  return 65.536f;
    case GYR_RANGE_1000DPS: return 32.768f;
    case GYR_RANGE_2000DPS: return 16.4f;
    default:                return 16.4f;
  }
}

bool BMI330_7Semi::readAccel(float &ax_g, float &ay_g, float &az_g)
{
  int16_t ax, ay, az;
  if (!readAccelRaw(ax, ay, az)) return false;

  /**
   * Datasheet expresses accel range in LSB/mg.
   * g = mg/1000; mg = raw / (LSB/mg)
   */
  const float lsbPerMg = accelLsbPerMg();
  ax_g = ((float)ax / lsbPerMg) / 1000.0f;
  ay_g = ((float)ay / lsbPerMg) / 1000.0f;
  az_g = ((float)az / lsbPerMg) / 1000.0f;
  return true;
}

bool BMI330_7Semi::readGyro(float &gx_dps, float &gy_dps, float &gz_dps)
{
  int16_t gx, gy, gz;
  if (!readGyroRaw(gx, gy, gz)) return false;

  const float lsbPerDps = gyroLsbPerDps();
  gx_dps = (float)gx / lsbPerDps;
  gy_dps = (float)gy / lsbPerDps;
  gz_dps = (float)gz / lsbPerDps;
  return true;
}

bool BMI330_7Semi::readTemperatureC(float &tempC)
{
  int16_t tRaw;
  if (!readTemperatureRaw(tRaw)) return false;

  /**
   * Temperature conversion:
   * The BMI330 datasheet defines TEMP_DATA.temp_data format and scaling.
   * We expose a conservative interpretation commonly used in BMI3 IMUs:
   *   tempC = (raw / 512) + 23
   * If you want exact conversion, use readTemperatureRaw() and apply your own scaling.
   */
  tempC = ((float)tRaw / 512.0f) + 23.0f;
  return true;
}

/* =========================
 * FIFO
 * ========================= */

bool BMI330_7Semi::setFifoConfig(const FifoConfig &cfg)
{
    uint16_t v = 0;
    if (!readReg(BMI330_REG_FIFO_CONF, v)) return false;

    // Clear and set stop_on_full (bit 0)
    v &= ~(1u << 0);
    v |= (cfg.stopOnFull ? 1u : 0u) << 0;

    // Clear and set time_en (bit 8)
    v &= ~(1u << 8);
    v |= (cfg.enableTime ? 1u : 0u) << 8;

    // Clear and set acc_en (bit 9)
    v &= ~(1u << 9);
    v |= (cfg.enableAccel ? 1u : 0u) << 9;

    // Clear and set gyr_en (bit 10)
    v &= ~(1u << 10);
    v |= (cfg.enableGyro ? 1u : 0u) << 10;

    // Clear and set temp_en (bit 11)
    v &= ~(1u << 11);
    v |= (cfg.enableTemp ? 1u : 0u) << 11;

    return writeReg(BMI330_REG_FIFO_CONF, v);
}


bool BMI330_7Semi::setFifoWatermarkWords(uint16_t watermarkWords)
{
  return writeReg(BMI330_REG_FIFO_WATERMARK, watermarkWords);
}

bool BMI330_7Semi::getFifoFillLevelWords(uint16_t &words)
{
  return readReg(BMI330_REG_FIFO_FILL_LEVEL, words);
}

bool BMI330_7Semi::flushFifo()
{
  /**
   * FIFO_CTRL contains fifo_flush bit(s). We keep this generic:
   * - write 1 to bit0 to flush (common pattern).
   * If you need precise bits, you can implement using datasheet.
   */
  uint16_t v = 0x0001;
  return writeReg(BMI330_REG_FIFO_CTRL, v);
}

// bool BMI330_7Semi::readFifoWords(uint16_t *dst, size_t wordsToRead)
// {
//   if (wordsToRead == 0) return true;

//   /**
//    * FIFO_DATA is a 16-bit word register. We read 2*wordsToRead bytes.
//    */
//   const size_t bytes = wordsToRead * 2;
//   uint8_t *buf = (uint8_t*)malloc(bytes);
//   if (!buf) return false;

//   const bool ok = readBurst(BMI330_REG_FIFO_DATA, buf, bytes);
//   if (!ok)
//   {
//     free(buf);
//     return false;
//   }

//   for (size_t i = 0; i < wordsToRead; i++)
//   {
//     dst[i] = (uint16_t)buf[i * 2 + 1] << 8 | buf[i * 2 + 0];
//   }

//   free(buf);
//   return true;
// }
bool BMI330_7Semi::readFifoWords(uint16_t *dst, size_t wordsToRead)
{
    if (wordsToRead == 0) return true;

    // Each word is 2 bytes, cast dst to uint8_t* to read bytes directly
    return readBurst(BMI330_REG_FIFO_DATA, reinterpret_cast<uint8_t*>(dst), wordsToRead * 2);
}


bool BMI330_7Semi::decodeFifoFrame(const uint16_t *frameWords, size_t frameWordCount, Sample &out)
{
  out = Sample{};

  size_t idx = 0;

  uint16_t fifoConf = 0;
  if (!readReg(BMI330_REG_FIFO_CONF, fifoConf)) return false;

  const bool accelEn  = ((fifoConf >> 9) & 0x01) != 0;  // acc_en is bit 9
const bool gyroEn  = ((fifoConf >> 10) & 0x01) != 0; // gyr_en is bit 10
const bool tempEn = ((fifoConf >> 11) & 0x01) != 0; // temp_en is bit 11
const bool timeEn = ((fifoConf >> 8) & 0x01) != 0;  // time_en is bit 8

  const size_t needed =
    (accelEn ? 3 : 0) +
    (gyroEn ? 3 : 0) +
    (tempEn ? 1 : 0) +
    (timeEn ? 1 : 0);

  if (frameWordCount < needed) return false;

  if (accelEn)
  {
    out.ax = (int16_t)frameWords[idx + 0];
    out.ay = (int16_t)frameWords[idx + 1];
    out.az = (int16_t)frameWords[idx + 2];
    out.has_accel = true;
    idx += 3;
  }

  if (gyroEn)
  {
    out.gx = (int16_t)frameWords[idx + 0];
    out.gy = (int16_t)frameWords[idx + 1];
    out.gz = (int16_t)frameWords[idx + 2];
    out.has_gyro = true;
    idx += 3;
  }

  if (tempEn)
  {
    out.t = (int16_t)frameWords[idx];
    out.has_temp = true;
    idx += 1;
  }

  if (timeEn)
  {
    out.sensortime = (uint32_t)frameWords[idx];
    out.has_time = true;
    idx += 1;
  }

  return true;
}

/* =========================
 * Interrupts
 * ========================= */

bool BMI330_7Semi::configInterruptPins(bool int1Enable, bool int2Enable, bool activeHigh, bool openDrain, bool latched)
{
    // Configure INT1 and INT2 pins
    if (!writeBit(BMI330_REG_IO_INT_CTRL, 0, stopOnFull ? 1u : 0u)) return false;
    
    // INT1: level, open-drain, enable
    if (!writeBit(BMI330_REG_IO_INT_CTRL, 0, activeHigh)) return false; // INT1 level
    if (!writeBit(BMI330_REG_IO_INT_CTRL, 1, openDrain)) return false;  // INT1 open-drain
    if (!writeBit(BMI330_REG_IO_INT_CTRL, 2, int1Enable)) return false; // INT1 enable

    // INT2: level, open-drain, enable
    if (!writeBit(BMI330_REG_IO_INT_CTRL, 8, activeHigh)) return false; // INT2 level
    if (!writeBit(BMI330_REG_IO_INT_CTRL, 9, openDrain)) return false;  // INT2 open-drain
    if (!writeBit(BMI330_REG_IO_INT_CTRL, 10, int2Enable)) return false; // INT2 enable

    // Configure latching in INT_CONF
    if (!writeBit(BMI330_REG_INT_CONF, 0, latched)) return false; // INT latch

    return true;
}


static uint16_t _set2bit(uint16_t v, uint8_t pos, uint8_t field)
{
  return BMI330_SET_BITS(v, pos, 2, field);
}

bool BMI330_7Semi::mapBasicInterrupts(IntRoute fifoFull, IntRoute fifoWm, IntRoute accelDrdy, IntRoute gyroDrdy, IntRoute tempDrdy, IntRoute errStatus, IntRoute tapOut)
{
    // FIFO_FULL (bits 15..14)
    if (!writeBit(BMI330_REG_INT_MAP2, 14, fifoFull & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP2, 15, (fifoFull >> 1) & 0x01)) return false;

    // FIFO_WM (bits 13..12)
    if (!writeBit(BMI330_REG_INT_MAP2, 12, fifoWm & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP2, 13, (fifoWm >> 1) & 0x01)) return false;

    // ACC_DRDY (bits 11..10)
    if (!writeBit(BMI330_REG_INT_MAP2, 10, accelDrdy & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP2, 11, (accelDrdy >> 1) & 0x01)) return false;

    // GYR_DRDY (bits 9..8)
    if (!writeBit(BMI330_REG_INT_MAP2, 8, gyroDrdy & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP2, 9, (gyroDrdy >> 1) & 0x01)) return false;

    // TEMP_DRDY (bits 7..6)
    if (!writeBit(BMI330_REG_INT_MAP2, 6, tempDrdy & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP2, 7, (tempDrdy >> 1) & 0x01)) return false;

    // ERR_STATUS (bits 5..4)
    if (!writeBit(BMI330_REG_INT_MAP2, 4, errStatus & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP2, 5, (errStatus >> 1) & 0x01)) return false;

    // TAP_OUT (bits 1..0)
    if (!writeBit(BMI330_REG_INT_MAP2, 0, tapOut & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP2, 1, (tapOut >> 1) & 0x01)) return false;

    return true;
}


bool BMI330_7Semi::mapFeatureInterrupts(IntRoute noMotion, IntRoute anyMotion, IntRoute flat, IntRoute orientation, IntRoute stepDetector, IntRoute stepCounter, IntRoute sigMotion, IntRoute tilt)
{
    // NO_MOTION (bits 1..0)
    if (!writeBit(BMI330_REG_INT_MAP1, 0, noMotion & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP1, 1, (noMotion >> 1) & 0x01)) return false;

    // ANY_MOTION (bits 3..2)
    if (!writeBit(BMI330_REG_INT_MAP1, 2, anyMotion & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP1, 3, (anyMotion >> 1) & 0x01)) return false;

    // FLAT (bits 5..4)
    if (!writeBit(BMI330_REG_INT_MAP1, 4, flat & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP1, 5, (flat >> 1) & 0x01)) return false;

    // ORIENTATION (bits 7..6)
    if (!writeBit(BMI330_REG_INT_MAP1, 6, orientation & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP1, 7, (orientation >> 1) & 0x01)) return false;

    // STEP_DETECTOR (bits 9..8)
    if (!writeBit(BMI330_REG_INT_MAP1, 8, stepDetector & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP1, 9, (stepDetector >> 1) & 0x01)) return false;

    // STEP_COUNTER (bits 11..10)
    if (!writeBit(BMI330_REG_INT_MAP1, 10, stepCounter & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP1, 11, (stepCounter >> 1) & 0x01)) return false;

    // SIG_MOTION (bits 13..12)
    if (!writeBit(BMI330_REG_INT_MAP1, 12, sigMotion & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP1, 13, (sigMotion >> 1) & 0x01)) return false;

    // TILT (bits 15..14)
    if (!writeBit(BMI330_REG_INT_MAP1, 14, tilt & 0x01)) return false;
    if (!writeBit(BMI330_REG_INT_MAP1, 15, (tilt >> 1) & 0x01)) return false;

    return true;
}


bool BMI330_7Semi::readIntStatusInt1(uint16_t &status)
{
  return readReg(BMI330_REG_INT_STATUS_INT1, status);
}

bool BMI330_7Semi::readIntStatusInt2(uint16_t &status)
{
  return readReg(BMI330_REG_INT_STATUS_INT2, status);
}

bool BMI330_7Semi::readIntStatusIbi(uint16_t &status)
{
  return readReg(BMI330_REG_INT_STATUS_IBI, status);
}

/* =========================
 * Feature engine control
 * ========================= */

bool BMI330_7Semi::_waitFeatureEngineReady(uint32_t timeoutMs)
{
  const uint32_t start = millis();
  while ((millis() - start) < timeoutMs)
  {
    uint16_t io1 = 0;
    if (!readReg(BMI330_REG_FEATURE_IO1, io1)) return false;

    const uint16_t err = BMI330_GET_BITS(io1, BMI330_FEATURE_ERROR_STATUS_POS, BMI330_FEATURE_ERROR_STATUS_WIDTH);

    /**
     * Datasheet: FEATURE_IO1.error_status provides "error and status information".
     * We treat err==0 as "no error", and also accept non-zero values (caller may read details).
     * For a stricter policy, read datasheet table for exact ready state codes.
     */
    (void)err;
    return true;
  }
  return false;
}

bool BMI330_7Semi::enableFeatureEngine()
{
  /**
   * Feature engine enable sequence (simplified):
   * - Write startup config words to FEATURE_IO2/FEATURE_IO3 if desired
   * - Trigger sync via FEATURE_IO_STATUS (write 1)
   * - Set FEATURE_CTRL.engine_en = 1
   */
  uint16_t ctrl = 0;
  if (!readReg(BMI330_REG_FEATURE_CTRL, ctrl)) return false;
  ctrl = BMI330_SET_BITS(ctrl, BMI330_FEATURE_ENGINE_EN_POS, 1, 1);
  if (!writeReg(BMI330_REG_FEATURE_CTRL, ctrl)) return false;

  return _waitFeatureEngineReady();
}

bool BMI330_7Semi::disableFeatureEngine()
{
  uint16_t ctrl = 0;
  if (!readReg(BMI330_REG_FEATURE_CTRL, ctrl)) return false;
  ctrl = BMI330_SET_BITS(ctrl, BMI330_FEATURE_ENGINE_EN_POS, 1, 0);
  return writeReg(BMI330_REG_FEATURE_CTRL, ctrl);
}

bool BMI330_7Semi::setFeatureEnableMask(uint16_t featureMask)
{
  return writeReg(BMI330_REG_FEATURE_IO0, featureMask);
}

bool BMI330_7Semi::getFeatureEnableMask(uint16_t &featureMask)
{
  return readReg(BMI330_REG_FEATURE_IO0, featureMask);
}

bool BMI330_7Semi::applyFeatureIO()
{
  /**
   * FEATURE_IO_STATUS bit0 triggers synchronization of FEATURE_IO0..3 with the feature engine. (datasheet)
   */
  return writeReg(BMI330_REG_FEATURE_IO_STATUS, 0x0001);
}

bool BMI330_7Semi::enableStepCounter(bool enable)
{
  uint16_t m = 0;
  if (!getFeatureEnableMask(m)) return false;
  if (enable) m |= FEAT_STEP_COUNTER;
  else        m &= (uint16_t)~FEAT_STEP_COUNTER;
  if (!setFeatureEnableMask(m)) return false;
  return applyFeatureIO();
}

bool BMI330_7Semi::enableStepDetector(bool enable)
{
  uint16_t m = 0;
  if (!getFeatureEnableMask(m)) return false;
  if (enable) m |= FEAT_STEP_DETECTOR;
  else        m &= (uint16_t)~FEAT_STEP_DETECTOR;
  if (!setFeatureEnableMask(m)) return false;
  return applyFeatureIO();
}

bool BMI330_7Semi::enableTap(bool singleTap, bool doubleTap, bool tripleTap)
{
  uint16_t m = 0;
  if (!getFeatureEnableMask(m)) return false;

  m = singleTap ? (uint16_t)(m | FEAT_TAP_SINGLE) : (uint16_t)(m & (uint16_t)~FEAT_TAP_SINGLE);
  m = doubleTap ? (uint16_t)(m | FEAT_TAP_DOUBLE) : (uint16_t)(m & (uint16_t)~FEAT_TAP_DOUBLE);
  m = tripleTap ? (uint16_t)(m | FEAT_TAP_TRIPLE) : (uint16_t)(m & (uint16_t)~FEAT_TAP_TRIPLE);

  if (!setFeatureEnableMask(m)) return false;
  return applyFeatureIO();
}

bool BMI330_7Semi::enableMotion(bool anyX, bool anyY, bool anyZ, bool noX, bool noY, bool noZ)
{
  uint16_t m = 0;
  if (!getFeatureEnableMask(m)) return false;

  auto setb = [&](uint16_t bit, bool en) { m = en ? (uint16_t)(m | bit) : (uint16_t)(m & (uint16_t)~bit); };
  setb(FEAT_ANY_MOTION_X, anyX);
  setb(FEAT_ANY_MOTION_Y, anyY);
  setb(FEAT_ANY_MOTION_Z, anyZ);
  setb(FEAT_NO_MOTION_X,  noX);
  setb(FEAT_NO_MOTION_Y,  noY);
  setb(FEAT_NO_MOTION_Z,  noZ);

  if (!setFeatureEnableMask(m)) return false;
  return applyFeatureIO();
}

bool BMI330_7Semi::enableOrientation(bool enable)
{
  uint16_t m = 0;
  if (!getFeatureEnableMask(m)) return false;
  if (enable) m |= FEAT_ORIENTATION;
  else        m &= (uint16_t)~FEAT_ORIENTATION;
  if (!setFeatureEnableMask(m)) return false;
  return applyFeatureIO();
}

bool BMI330_7Semi::enableFlat(bool enable)
{
  uint16_t m = 0;
  if (!getFeatureEnableMask(m)) return false;
  if (enable) m |= FEAT_FLAT;
  else        m &= (uint16_t)~FEAT_FLAT;
  if (!setFeatureEnableMask(m)) return false;
  return applyFeatureIO();
}

bool BMI330_7Semi::enableTilt(bool enable)
{
  uint16_t m = 0;
  if (!getFeatureEnableMask(m)) return false;
  if (enable) m |= FEAT_TILT;
  else        m &= (uint16_t)~FEAT_TILT;
  if (!setFeatureEnableMask(m)) return false;
  return applyFeatureIO();
}

bool BMI330_7Semi::enableSignificantMotion(bool enable)
{
  uint16_t m = 0;
  if (!getFeatureEnableMask(m)) return false;
  if (enable) m |= FEAT_SIG_MOTION;
  else        m &= (uint16_t)~FEAT_SIG_MOTION;
  if (!setFeatureEnableMask(m)) return false;
  return applyFeatureIO();
}

bool BMI330_7Semi::readStepCount(uint32_t &steps)
{
  uint16_t lo = 0, hi = 0;
  if (!readReg(BMI330_REG_FEATURE_IO2, lo)) return false;
  if (!readReg(BMI330_REG_FEATURE_IO3, hi)) return false;
  steps = ((uint32_t)hi << 16) | (uint32_t)lo;
  return true;
}

/* =========================
 * Extended feature configuration (FEATURE_DATA_* registers)
 * ========================= */

bool BMI330_7Semi::extWrite(uint16_t extAddress, uint16_t value)
{
  /**
   * EXT addressing is set via FEATURE_DATAaddress, then write value to FEATURE_DATA_TX.
   * The FEATURE_DATA_STATUS register indicates completion (device dependent).
   *
   * We keep it simple: write addr, write value, and return true.
   * If you need strict sync, poll FEATURE_DATA_STATUS.
   */
  if (!writeReg(BMI330_REG_FEATURE_DATA_ADDR, extAddress)) return false;
  return writeReg(BMI330_REG_FEATURE_DATA_TX, value);
}

bool BMI330_7Semi::extRead(uint16_t extAddress, uint16_t &value)
{
  if (!writeReg(BMI330_REG_FEATURE_DATA_ADDR, extAddress)) return false;
  return readReg(BMI330_REG_FEATURE_DATA_TX, value);
}

bool BMI330_7Semi::extWriteBlock(uint16_t startExtAddress, const uint16_t *values, size_t wordCount)
{
  for (size_t i = 0; i < wordCount; i++)
  {
    if (!extWrite((uint16_t)(startExtAddress + i), values[i])) return false;
  }
  return true;
}

