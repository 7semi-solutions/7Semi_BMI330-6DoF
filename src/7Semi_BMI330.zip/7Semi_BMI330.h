#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <SPI.h>
#include "7Semi_BMI330_defs.h"

/**
 * 7Semi BMI330 driver (no official Bosch library)
 *
 * - Works with I²C (and supports SPI if you wire CS + provide SPI bus)
 * - Uses BMI330 16-bit register words and required dummy bytes on read (datasheet)
 * - Provides: accel, gyro, temperature, sensortime, FIFO, interrupts, and feature engine control
 *
 * Notes
 * - The advanced features (step, tap, any/no motion, orientation, flat, tilt, sig-motion, etc.)
 *   live in the "feature engine". You must enable it first, then enable individual features via FEATURE_IO0.
 * - Feature tuning parameters are in the "EXT" configuration space accessed by FEATURE_DATA_ADDR/TX.
 *   This library exposes generic read/write helpers so you can implement/tune any feature without vendor code.
 */

class BMI330_7Semi
{
public:
  /** Communication type selection */
  enum class Bus : uint8_t
  {
    NONE,
    I2C,
    SPI
  };

  /** Output Data Rate codes (ACC_CONF.acc_odr / GYR_CONF.gyr_odr) */
  enum ODR : uint8_t
  {
    ODR_0_78125HZ = 0x01,
    ODR_1_5625HZ = 0x02,
    ODR_3_125HZ = 0x03,
    ODR_6_25HZ = 0x04,
    ODR_12_5HZ = 0x05,
    ODR_25HZ = 0x06,
    ODR_50HZ = 0x07,
    ODR_100HZ = 0x08,
    ODR_200HZ = 0x09,
    ODR_400HZ = 0x0A,
    ODR_800HZ = 0x0B,
    ODR_1_6KHZ = 0x0C,
    ODR_3_2KHZ = 0x0D,
    ODR_6_4KHZ = 0x0E,
  };

  /** Accelerometer full-scale range (ACC_CONF.acc_range) */
  enum AccRange : uint8_t
  {
    ACC_RANGE_2G = 0x0,  /* 16.38 LSB/mg */
    ACC_RANGE_4G = 0x1,  /* 8.19  LSB/mg */
    ACC_RANGE_8G = 0x2,  /* 4.10  LSB/mg */
    ACC_RANGE_16G = 0x3, /* 2.05  LSB/mg */
  };

  /** Gyroscope full-scale range (GYR_CONF.gyr_range) */
  enum GyrRange : uint8_t
  {
    GYR_RANGE_125DPS = 0x0,  /* 262.144 LSB/°/s */
    GYR_RANGE_250DPS = 0x1,  /* 131.072 LSB/°/s */
    GYR_RANGE_500DPS = 0x2,  /* 65.536  LSB/°/s */
    GYR_RANGE_1000DPS = 0x3, /* 32.768  LSB/°/s */
    GYR_RANGE_2000DPS = 0x4, /* 16.4    LSB/°/s */
  };

  /** Bandwidth selection (ACC_CONF.acc_bw / GYR_CONF.gyr_bw) */
  enum BW : uint8_t
  {
    BW_ODR_DIV2 = 0x0,
    BW_ODR_DIV4 = 0x1,
  };

  /** Averaging selection (ACC_CONF.acc_avg_num / GYR_CONF.gyr_avg_num) */
  enum AVG : uint8_t
  {
    AVG_OFF = 0x0,
    AVG_2 = 0x1,
    AVG_4 = 0x2,
    AVG_8 = 0x3,
    AVG_16 = 0x4,
    AVG_32 = 0x5,
    AVG_64 = 0x6,
  };

  /** Sensor operation mode (ACC_CONF.acc_mode / GYR_CONF.gyr_mode) */
  enum Mode : uint8_t
  {
    MODE_DISABLE = 0x0,
    MODE_GYR_DRIVE_ONLY = 0x1, /* gyro only */
    MODE_DUTY_CYCLE = 0x3,
    MODE_CONTINUOUS_LP = 0x4,
    MODE_HIGH_PERFORMANCE = 0x7,
  };

  /** Interrupt route selection for INT_MAP1/2 (2-bit fields) */
  enum IntRoute : uint8_t
  {
    INT_DISABLED = 0x0,
    INT_TO_INT1 = 0x1,
    INT_TO_INT2 = 0x2,
    INT_TO_IBI = 0x3, /* I3C only */
  };

  /** FIFO source selection */
  struct FifoConfig
  {
    bool enableAccel = false;
    bool enableGyro = false;
    bool enableTemp = false;
    bool enableTime = false;
    bool stopOnFull = false;
  };

  /** Decoded sensor sample */
  struct Sample
  {
    int16_t ax = 0, ay = 0, az = 0;
    int16_t gx = 0, gy = 0, gz = 0;
    int16_t t = 0;
    uint32_t sensortime = 0;
    bool has_accel = false;
    bool has_gyro = false;
    bool has_temp = false;
    bool has_time = false;
  };

  /** Feature enables controlled through FEATURE_IO0 */
  enum Feature : uint16_t
  {
    FEAT_NO_MOTION_X = (1u << BMI330_FEAT_NO_MOTION_X_EN_POS),
    FEAT_NO_MOTION_Y = (1u << BMI330_FEAT_NO_MOTION_Y_EN_POS),
    FEAT_NO_MOTION_Z = (1u << BMI330_FEAT_NO_MOTION_Z_EN_POS),
    FEAT_ANY_MOTION_X = (1u << BMI330_FEAT_ANY_MOTION_X_EN_POS),
    FEAT_ANY_MOTION_Y = (1u << BMI330_FEAT_ANY_MOTION_Y_EN_POS),
    FEAT_ANY_MOTION_Z = (1u << BMI330_FEAT_ANY_MOTION_Z_EN_POS),
    FEAT_FLAT = (1u << BMI330_FEAT_FLAT_EN_POS),
    FEAT_ORIENTATION = (1u << BMI330_FEAT_ORIENTATION_EN_POS),
    FEAT_STEP_DETECTOR = (1u << BMI330_FEAT_STEP_DETECTOR_EN_POS),
    FEAT_STEP_COUNTER = (1u << BMI330_FEAT_STEP_COUNTER_EN_POS),
    FEAT_SIG_MOTION = (1u << BMI330_FEAT_SIG_MOTION_EN_POS),
    FEAT_TILT = (1u << BMI330_FEAT_TILT_EN_POS),
    FEAT_TAP_SINGLE = (1u << BMI330_FEAT_TAP_S_EN_POS),
    FEAT_TAP_DOUBLE = (1u << BMI330_FEAT_TAP_D_EN_POS),
    FEAT_TAP_TRIPLE = (1u << BMI330_FEAT_TAP_T_EN_POS),
    FEAT_I3C_TC_SYNC = (1u << BMI330_FEAT_I3C_SYNC_EN_POS),
  };

public:
  /* I2C constructor */
  /* SPI constructor */
  BMI330_7Semi();

  /** Begin and basic bring-up */
  bool begin();
  bool beginI2C(uint8_t address = 0x69,
                TwoWire &wire = Wire,
                uint32_t clock = 400000,
                uint8_t sda = 255,
                uint8_t scl = 255);

  bool beginSPI(uint8_t csPin,
                SPIClass &spiPort = SPI,
                uint32_t clock = 10000000,
                uint8_t sck = 255,
                uint8_t miso = 255,
                uint8_t mosi = 255);

  /** Soft reset device */
  bool softReset();

  /** Raw register I/O (16-bit word) */
  bool writeReg(uint8_t reg, uint16_t value);
  bool readReg(uint8_t reg, uint16_t &value);

  /** Burst read of N bytes payload (after required dummy bytes) */
  bool readBytes(uint8_t startReg, uint8_t *buffer, size_t length);
  bool readBit(uint8_t reg, uint8_t bitPos, bool &bitValue);
  bool writeBit(uint8_t reg, uint8_t bitPos, bool bitValue);

  /** Read basic status/error */
  bool readChipID(uint16_t &chipId);
  bool readStatus(uint16_t &status);
  bool readError(uint16_t &error);

  /** Configure accel / gyro */
  bool setAccelConfig(ODR odr, AccRange range, BW bw, AVG avg, Mode mode);
  bool setGyroConfig(ODR odr, GyrRange range, BW bw, AVG avg, Mode mode);

  /** Read sensor outputs (raw and scaled) */
  bool readAccelRaw(int16_t &ax, int16_t &ay, int16_t &az);
  bool readGyroRaw(int16_t &gx, int16_t &gy, int16_t &gz);
  bool readTemperatureRaw(int16_t &t);
  bool readSensorTime(uint32_t &time24);

  bool readAccel(float &ax_g, float &ay_g, float &az_g);
  bool readGyro(float &gx_dps, float &gy_dps, float &gz_dps);
  bool readTemperatureC(float &tempC);

  /** FIFO */
  bool setFifoConfig(const FifoConfig &cfg);
  bool setFifoWatermarkWords(uint16_t watermarkWords);
  bool getFifoFillLevelWords(uint16_t &words);
  bool flushFifo();
  bool readFifoWords(uint16_t *dst, size_t wordsToRead);

  /**
   * Decode one FIFO frame based on current FIFO_CONF enable bits.
   *
   * - BMI330 FIFO frames have no header and use a fixed order:
   *   Accelerometer(3) -> Gyroscope(3) -> Temperature(1) -> Sensortime(1). (datasheet table: FIFO order)
   * - You must know which sources are enabled to parse correctly.
   */
  bool decodeFifoFrame(const uint16_t *frameWords, size_t frameWordCount, Sample &out);

  /** Interrupt pins configuration */
  bool configInterruptPins(bool int1Enable, bool int2Enable, bool activeHigh, bool openDrain, bool latched);

  /** Map interrupts to pins */
  bool mapBasicInterrupts(IntRoute fifoFull, IntRoute fifoWm, IntRoute accDrdy, IntRoute gyrDrdy, IntRoute tempDrdy, IntRoute errStatus, IntRoute tapOut);
  bool mapFeatureInterrupts(IntRoute noMotion, IntRoute anyMotion, IntRoute flat, IntRoute orientation, IntRoute stepDetector, IntRoute stepCounter, IntRoute sigMotion, IntRoute tilt);

  /** Read interrupt status registers (INT_STATUS_INT1 / INT_STATUS_INT2 / INT_STATUS_IBI) */
  bool readIntStatusInt1(uint16_t &status);
  bool readIntStatusInt2(uint16_t &status);
  bool readIntStatusIbi(uint16_t &status);

  /** Feature engine control */
  bool enableFeatureEngine();
  bool disableFeatureEngine();

  /** Enable/disable features via FEATURE_IO0 and apply via FEATURE_IO_STATUS */
  bool setFeatureEnableMask(uint16_t featureMask);
  bool getFeatureEnableMask(uint16_t &featureMask);
  bool applyFeatureIO();

  /** Convenience feature helpers */
  bool enableStepCounter(bool enable);
  bool enableStepDetector(bool enable);
  bool enableTap(bool singleTap, bool doubleTap, bool tripleTap);
  bool enableMotion(bool anyX, bool anyY, bool anyZ, bool noX, bool noY, bool noZ);
  bool enableOrientation(bool enable);
  bool enableFlat(bool enable);
  bool enableTilt(bool enable);
  bool enableSignificantMotion(bool enable);

  /** Read step counter (32-bit) from FEATURE_IO2/3 */
  bool readStepCount(uint32_t &steps);

  /** Extended feature configuration access (FEATURE_DATA_ADDR/TX/STATUS) */
  bool extWrite(uint16_t extAddress, uint16_t value);
  bool extRead(uint16_t extAddress, uint16_t &value);

  /** Helper: set multiple EXT addresses */
  bool extWriteBlock(uint16_t startExtAddress, const uint16_t *values, size_t wordCount);

private:
  Bus bus = Bus::NONE;

  /* I2C */
  uint8_t address = BMI330_DEFAULT_I2C_ADDR;
  TwoWire *i2c = nullptr;
  uint32_t i2c_clock_speed = 400000;

  /* SPI */
  uint8_t cs = 255;
  SPIClass *spi = nullptr;
  uint32_t spi_clock_speed = 10000000;

  /* Cached ranges for scaling */
  AccRange accel_range = ACC_RANGE_2G;
  GyrRange gyro_range = GYR_RANGE_2000DPS;

private:
  /** Combine two bytes to signed 16-bit */
  static int16_t bytesToUint16(uint8_t lsb, uint8_t msb) { return (int16_t)((uint16_t)msb << 8 | lsb); }

  /** Read register words as bytes with proper dummy bytes for the active bus */
  bool readBurst(uint8_t startReg, uint8_t *buffer, size_t length);

  /** SPI helpers */
  bool i2cRead(uint8_t reg, uint8_t *buf, size_t len);
  bool i2cWrite(uint8_t reg, const uint8_t *buf, size_t len);
  bool spiRead(uint8_t reg, uint8_t *buf, size_t len);
  bool spiWrite(uint8_t reg, const uint8_t *buf, size_t len);

  /** Scaling helpers */
  float accelLsbPerMg() const;
  float gyroLsbPerDps() const;

  /** Bitfield helper */
  bool _updateRegisterField(uint8_t reg, uint8_t pos, uint8_t width, uint16_t fieldValue);

  /** Feature engine init polling */
  bool _waitFeatureEngineReady(uint32_t timeoutMs = 200);
};
